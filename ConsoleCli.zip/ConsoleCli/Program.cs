﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("Digite a sua idade:");
int idade = Convert.ToInt32(Console.ReadLine());

if(idade >= 18)
{
    Console.WriteLine("Maior de idade");
}
else
{
    Console.WriteLine("Menor de idade");
}